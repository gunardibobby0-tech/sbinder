import type { Express } from "express";
import type { Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { z } from "zod";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { registerChatRoutes } from "./replit_integrations/chat";
import { extractScriptData, generateScript, AVAILABLE_MODELS } from "./replit_integrations/ai/client";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth setup
  await setupAuth(app);
  registerAuthRoutes(app);
  registerChatRoutes(app);

  // === Settings ===
  app.get(api.settings.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const settings = await storage.getUserSettings(userId);
    res.json({
      openrouterToken: settings?.openrouterToken ? "***" : undefined,
      preferredModel: settings?.preferredModel || "meta-llama/llama-3.3-70b-instruct",
    });
  });

  app.get(api.settings.models.path, async (req, res) => {
    res.json(AVAILABLE_MODELS);
  });

  app.put(api.settings.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    try {
      const input = z.object({ 
        openrouterToken: z.string().optional(),
        preferredModel: z.string().optional(),
      }).parse(req.body);
      
      // Only store if a token is provided
      if (input.openrouterToken) {
        process.env.OPENROUTER_API_KEY = input.openrouterToken;
      }
      
      await storage.updateUserSettings(userId, input);
      res.json({
        openrouterToken: input.openrouterToken ? "***" : undefined,
        preferredModel: input.preferredModel || "meta-llama/llama-3.3-70b-instruct",
      });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // === Projects ===
  app.get(api.projects.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const userId = (req.user as any).claims.sub;
    const projects = await storage.getProjects(userId);
    res.json(projects);
  });

  app.get(api.projects.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const project = await storage.getProject(Number(req.params.id));
    if (!project) return res.sendStatus(404);
    res.json(project);
  });

  app.post(api.projects.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.projects.create.input.parse(req.body);
      const userId = (req.user as any).claims.sub;
      const project = await storage.createProject({ ...input, ownerId: userId });
      res.status(201).json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.put(api.projects.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.projects.update.input.parse(req.body);
      const project = await storage.updateProject(Number(req.params.id), input);
      res.json(project);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.projects.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    await storage.deleteProject(Number(req.params.id));
    res.sendStatus(204);
  });

  // === Documents ===
  app.get(api.documents.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const documents = await storage.getDocuments(Number(req.params.projectId));
    res.json(documents);
  });

  app.post(api.documents.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.documents.create.input.parse(req.body);
      const document = await storage.createDocument({
        ...input,
        projectId: Number(req.params.projectId)
      });
      res.status(201).json(document);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.get(api.documents.get.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const document = await storage.getDocument(Number(req.params.id));
    if (!document) return res.sendStatus(404);
    res.json(document);
  });

  app.put(api.documents.update.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.documents.update.input.parse(req.body);
      const document = await storage.updateDocument(Number(req.params.id), input);
      res.json(document);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.documents.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    await storage.deleteDocument(Number(req.params.id));
    res.sendStatus(204);
  });

  // === Document Import ===
  app.post(api.documents.import.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.documents.import.input.parse(req.body);
      const projectId = Number(req.params.projectId);
      const userId = (req.user as any).claims.sub;

      const userSettings = await storage.getUserSettings(userId);
      const model = input.model || userSettings?.preferredModel || "meta-llama/llama-3.3-70b-instruct";

      const extractedData = await extractScriptData(input.content, model);

      const script = await storage.createDocument({
        projectId,
        type: "Script",
        title: input.fileName || "Imported Script",
        content: extractedData.scriptContent,
        status: "draft"
      });

      const castContacts = await Promise.all(
        extractedData.cast.map(c =>
          storage.createContact({
            projectId,
            name: c.name,
            role: c.role,
            category: "Cast"
          })
        )
      );

      const crewContacts = await Promise.all(
        extractedData.crew.map(c =>
          storage.createContact({
            projectId,
            name: c.name,
            role: c.role,
            category: "Crew"
          })
        )
      );

      const now = new Date();
      const scheduleEvents = await Promise.all(
        extractedData.schedule.map((s, idx) => {
          const startTime = new Date(now.getTime() + idx * 24 * 60 * 60 * 1000);
          const endTime = new Date(startTime.getTime() + s.duration * 60 * 1000);
          return storage.createEvent({
            projectId,
            title: s.title,
            startTime,
            endTime,
            type: "Shoot",
            description: s.description
          });
        })
      );

      res.status(201).json({
        script,
        contacts: [...castContacts, ...crewContacts],
        events: scheduleEvents,
      });
    } catch (err) {
      console.error("Document import error:", err);
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({
        message: err instanceof Error ? err.message : "Failed to import document"
      });
    }
  });

  // === Document Script Generation ===
  app.post(api.documents.generate.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.documents.generate.input.parse(req.body);
      const docId = Number(req.params.id);
      const userId = (req.user as any).claims.sub;

      const document = await storage.getDocument(docId);
      if (!document) return res.sendStatus(404);

      const userSettings = await storage.getUserSettings(userId);
      const model = input.model || userSettings?.preferredModel || "meta-llama/llama-3.3-70b-instruct";

      const generatedScript = await generateScript(input.prompt, model);

      const updated = await storage.updateDocument(docId, {
        content: generatedScript,
        status: "draft"
      });

      res.json(updated);
    } catch (err) {
      console.error("Script generation error:", err);
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      res.status(500).json({
        message: err instanceof Error ? err.message : "Failed to generate script"
      });
    }
  });

  // === Contacts ===
  app.get(api.contacts.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const contacts = await storage.getContacts(Number(req.params.projectId));
    res.json(contacts);
  });

  app.post(api.contacts.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.contacts.create.input.parse(req.body);
      const contact = await storage.createContact({
        ...input,
        projectId: Number(req.params.projectId)
      });
      res.status(201).json(contact);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.contacts.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    await storage.deleteContact(Number(req.params.id));
    res.sendStatus(204);
  });

  // === Events ===
  app.get(api.events.list.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const events = await storage.getEvents(Number(req.params.projectId));
    res.json(events);
  });

  app.post(api.events.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const input = api.events.create.input.parse(req.body);
      const event = await storage.createEvent({
        ...input,
        projectId: Number(req.params.projectId)
      });
      res.status(201).json(event);
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.events.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    await storage.deleteEvent(Number(req.params.id));
    res.sendStatus(204);
  });

  return httpServer;
}
