import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { format } from "date-fns";
import type { Event } from "@shared/schema";
import { Clock, MapPin, Users } from "lucide-react";
import { useState } from "react";

interface ScheduleDetailDialogProps {
  event: Event | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function ScheduleDetailDialog({
  event,
  open,
  onOpenChange,
}: ScheduleDetailDialogProps) {
  const [isEditing, setIsEditing] = useState(false);

  if (!event) return null;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="bg-[#1c2128] border-white/10 text-white max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{event.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Event Type & Status */}
          <div className="flex gap-4">
            <span className={`px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
              event.type === 'Shoot' ? 'bg-red-500/20 text-red-400' :
              event.type === 'Meeting' ? 'bg-blue-500/20 text-blue-400' :
              'bg-green-500/20 text-green-400'
            }`}>
              {event.type}
            </span>
          </div>

          {/* Schedule Details */}
          <Card className="bg-black/20 border-white/10 p-4 space-y-3">
            <div className="flex items-center gap-3 text-muted-foreground">
              <Clock className="w-4 h-4" />
              <div>
                <span className="text-sm">{format(new Date(event.startTime), "EEEE, MMMM d, yyyy")}</span>
                <span className="text-white ml-2 font-medium">
                  {format(new Date(event.startTime), "h:mm a")} - {format(new Date(event.endTime), "h:mm a")}
                </span>
              </div>
            </div>

            {event.description && (
              <div className="flex items-center gap-3 text-muted-foreground">
                <MapPin className="w-4 h-4" />
                <span className="text-white">{event.description}</span>
              </div>
            )}
          </Card>

          {/* Attendees Section */}
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <Users className="w-4 h-4 text-primary" />
              <h3 className="font-semibold">Expected Attendees</h3>
            </div>
            <Card className="bg-black/20 border-white/10 p-4">
              <p className="text-sm text-muted-foreground">
                Crew assignments for this schedule event will appear here once configured.
              </p>
            </Card>
          </div>

          {/* Event Notes */}
          <div className="space-y-2">
            <label className="text-sm font-medium">Notes</label>
            <Textarea
              className="bg-black/20 border-white/10 text-white resize-none"
              placeholder="Add any additional details about this schedule..."
              defaultValue={event.description || ""}
              disabled={!isEditing}
              rows={3}
            />
          </div>

          {/* Action Buttons */}
          <div className="flex justify-end gap-2 pt-4">
            <Button
              variant="ghost"
              onClick={() => onOpenChange(false)}
            >
              Close
            </Button>
            <Button
              className="bg-primary hover:bg-primary/90"
              onClick={() => setIsEditing(!isEditing)}
            >
              {isEditing ? "Save Changes" : "Edit Schedule"}
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
